<html>
<body>
<form action="welcome.php" method="post"> 
	Enter your name: <input type="text" name="name" /> 
	Enter your age: <input type="text" name="age" /> 
	<input value="OK" type="submit" />
</form>
</body>
</html>